function addtocart(proid) {
    $.ajax({
        url: '/add-to-cart/' + proid,
        method: 'get',
        success: (response) => {
            if (response.status) {
                let count = $('#cart-count').html()
                count = parseInt(count) + 1
                $("#cart-count").html(count)
                $(".hidemeassage").show().delay(1000).fadeOut();
            }
        }
    })
}
function changequantity(cartid, proid, userid, count) {
    let quantity = parseInt(document.getElementById(proid).innerHTML)
    count = parseInt(count)
    $.ajax({
        url: '/change-product-quantity',
        data: {
            user: userid,
            cart: cartid,
            product: proid,
            count: count,
            quantity: quantity
        },
        method: 'post',
        success: (response) => {
            if (response.removeproduct) {
                alert('Product removed from Cart')
                location.reload()
            } else {
                document.getElementById(proid).innerHTML = quantity + count
                document.getElementById('total').innerHTML = response.total
            }
        }
    })
}
//COD


$("#checkout-form").submit((e) => {
    e.preventDefault();
    $.ajax({
        method: 'post',
        url: '/place-order',
        data: $('#checkout-form').serialize(),
        success: (response) => {
            if (response.status) {
                if (response.codSuccess) {
                    location.href = '/order-success'
                } else {
                    razropayPayment(response)
                }
            } else {

                alert('failed' + response.error)
                let array = response.error
                let l = array.length
                let value = 0
                let string = []
                let result = ""
                for (i = 0; i < l; i++) {
                    if (i % 2 == 0) {
                        result = result.concat(" Product: ", array[i]);
                    } else {

                        result = result.concat(" ,Availability: ", array[i]);

                        value = ""
                    }
                }

                location.href = '/cart/' + result
            }
        }
        // ,error:(response)=>{
        //     alert('failed')
        // }
    })
})

function razropayPayment(order) {
    var options = {
        "key": "rzp_test_ZYmc7jEEIxRsLW", // Enter the Key ID generated from the Dashboard
        "amount": order.amount, // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
        "currency": "INR",
        "name": "Book Mart",
        "description": "Test Transaction",
        "image": "https://example.com/your_logo",
        "order_id": order.id, //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
        "handler": function (response) {
            // alert(response.razorpay_payment_id);
            // alert(response.razorpay_order_id);
            // alert(response.razorpay_signature);
            verifyPayment(response, order)
        },
        "prefill": {
            "name": "Gaurav Kumar",
            "email": "gaurav.kumar@example.com",
            "contact": "9999999999"
        },
        "notes": {
            "address": "Razorpay Corporate Office"
        },
        "theme": {
            "color": "#3399cc"
        },
        "modal": {
            "ondismiss": function () {
                location.href = '/orders'
            }
        }
    };
    var rzp1 = new Razorpay(options);
    rzp1.open();
}
function verifyPayment(payment, order) {
    $.ajax({
        type: "POST",
        url: '/verify-payment',
        data: {
            payment,
            order
        },
        method: 'post',
        success: (response) => {
            if (response.status) {
                location.href = '/order-success'
            } else {
                let result = "Payment failed"
                location.href = '/cart/' + result
                alert("payment failed")
            }
        }
    })
}


$("#changestatus").submit((e) => {
    e.preventDefault();
    $.ajax({

        url: '/admin/change-status',
        type:"POST",
        data:$('#changestatus').serialize(),
        dataType: "json",
        success: (response) => {
            if (response) {
                location.href = '/admin/orders'
            } else {
                location.href = '/admin/orders'
            }
        }
    })
})